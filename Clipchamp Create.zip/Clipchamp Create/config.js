window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Clipchamp Create",
   "homepage": "https://app.clipchamp.com",
   "enableHomeBttn": false,
   "enableReloadBttn": true,
   "enableLogoutBttn": false,
   "sessionDataTimeoutTime": 60,
   "sessionTimeoutTime": 30,
   "kioskEnabled": false
};